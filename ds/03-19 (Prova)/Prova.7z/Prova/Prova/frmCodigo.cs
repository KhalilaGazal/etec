﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btVerificar_Click(object sender, EventArgs e)
        {
            int i, mult3, mult1, soma, resto, digito;

            int[] vetor = new int[13];

            for(i = 0; i < vetor.Length; i++)
            {
                vetor[i] = int.Parse(txtCodigo.Text.Substring(i, 1));
            }

            mult3 = (vetor[1] + vetor[3] + vetor[5] + vetor[7] + vetor[9] + vetor[11]) * 3;
            mult1 = (vetor[0] + vetor[2] + vetor[4] + vetor[6] + vetor[8] + vetor[10]) * 1;
            soma = mult3 + mult1;
            resto = soma % 10;
            
            if(resto == 0)
            {
                digito = 0;
            }
            else
            {
                digito = 10 - resto;
            }

            if(vetor[12]==digito)
            {
                lblResultado.Text = Convert.ToString("Dígito correto");
            }
            else
            {
                lblResultado.Text = Convert.ToString("Dígito incorreto");
            }            

            if (vetor[0] == 7)
            {
                if(vetor[1] == 8 || vetor[1] == 9)
                {
                    if(vetor[2] == 9 || vetor[2] == 0)
                    {
                        lblResultado.Text += Convert.ToString("\nCódigo gerado no Brasil.");
                    }
                }
            }
            else
            {
                lblResultado.Text += Convert.ToString("\nCódigo gerado em outro país.");
            }          

        }
    }
}
