﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace KhalilaGazal
{
    class clBd
    {
        private static MySqlConnection cnUsuarios; //MySQL

        private static string strConex = "server=localhost;database=bdUsuario;uid=root";

        public static void Alterar(clUsuario usuario, int codigo)
        {
            cnUsuarios = new MySqlConnection(strConex);
            string strSql = "UPDATE tbUsuarios SET  " +
                "Nome = '" + usuario.Nome + "'," +
                "Email = '" + usuario.Email + "'," +
                "Nível = '" + usuario.Nivel.ToString() + "'," +
                "Login = '" + usuario.Login + "'," +                
                "Senha = '" + usuario.Senha + "'" +
                " WHERE Codigo = " + codigo.ToString();
            cnUsuarios.Open();
            MySqlCommand cmdSql = new MySqlCommand(strSql, cnUsuarios);
            cmdSql.ExecuteNonQuery();

            cnUsuarios.Close();
        }

        public static void Incluir(clUsuario usuario)
        {
            cnUsuarios = new MySqlConnection(strConex);
            string strSql = "INSERT INTO tbUsuarios  " +
                "(Codigo,Nome,Email,Nivel,Login,Senha)" +
                "VALUES (" +
                usuario.Codigo.ToString() + ",'" +
                usuario.Nome + "','" +
                usuario.Email + "','" +
                usuario.Nivel.ToString() + "','" +
                usuario.Login + "','" +
                usuario.Senha + "')";
            MessageBox.Show(strSql);
            try
            {
                cnUsuarios.Open();
                MySqlCommand cmdSql = new MySqlCommand(strSql, cnUsuarios);
                cmdSql.ExecuteNonQuery();
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.Message);
                usuario.Codigo = 0;

            }
            finally
            {
                cnUsuarios.Close();
            }
        }

        public static void Excluir(int codigo)
        {
            cnUsuarios = new MySqlConnection(strConex);
            string strSql = "DELETE FROM tbUsuarios  " +
                "WHERE Codigo = " + codigo.ToString();
            cnUsuarios.Open();
            MySqlCommand cmdSql = new MySqlCommand(strSql, cnUsuarios);
            cmdSql.ExecuteNonQuery();
            cnUsuarios.Close();
        }

        public static void Buscar(clUsuario usuario, int codigo)
        {
            cnUsuarios = new MySqlConnection(strConex);
            string Comando = "SELECT * FROM tbUsuarios  " +
                "WHERE Codigo = " + codigo.ToString();
            try
            {
                cnUsuarios.Open();
                MySqlCommand cmdSql = new MySqlCommand(Comando, cnUsuarios);
                MySqlDataReader rs;
                rs = cmdSql.ExecuteReader();
                rs.Read();
                if (rs.HasRows)
                {
                    usuario.Codigo = rs.GetInt32(0);
                    usuario.Nome = rs.GetString(1);
                    usuario.Email = rs.GetString(2);
                    usuario.Nivel = rs.GetInt32(3);
                    usuario.Login = rs.GetString(4);
                    usuario.Senha = rs.GetString(5);
                }
                rs.Close();
                cnUsuarios.Close();
            }
            catch (MySqlException e)
            {
                MessageBox.Show(e.Message);
                Application.Exit();
            }
        }

    }
}
