﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KhalilaGazal
{
    public partial class frmCadastro : Form
    {
        public frmCadastro()
        {
            InitializeComponent();
        }
        private void limpar()
        {
            txtBuscar.Clear();
            txtCodigo.Clear();
            txtNome.Clear();
            txtEmail.Clear();
            txtNivel.Clear();
            txtLogin.Clear();
            txtSenha.Clear();
            txtBuscar.Focus();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string strCodigo;
            int v;
            if (!Int32.TryParse(txtBuscar.Text.Trim(), out v))
            {
                MessageBox.Show("Erro na digitação do código", "Erro", MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                txtBuscar.Focus();
                return;
            }
            clUsuario usuario = new clUsuario();
            clBd.Buscar(usuario, Convert.ToInt32(txtBuscar.Text));
            if (usuario.Codigo != 0)
            {
                txtCodigo.Text = usuario.Codigo.ToString();
                txtNome.Text = usuario.Nome;
                txtEmail.Text = usuario.Email;
                txtNivel.Text = usuario.Nivel.ToString();
                txtLogin.Text = usuario.Login;
                txtSenha.Text = usuario.Senha;
                btnExcluir.Enabled = true;
                btnSalvar.Enabled = true;
            }
            else
            {
                MessageBox.Show("Registro não existe");
                btnNovo.Enabled = true;
                btnExcluir.Enabled = false;
                strCodigo = txtBuscar.Text;
                limpar();
                txtCodigo.Text = strCodigo;
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtCodigo.Focus();
            btnBuscar.Enabled = false;
            btnSalvar.Tag = "i";
            txtCodigo.ReadOnly = false;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = true;
            btnNovo.Enabled = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            txtCodigo.ReadOnly = false;
            clUsuario usuario = new clUsuario();
            try
            {
                usuario.Codigo = Convert.ToInt32(txtCodigo.Text);
                usuario.Nome = txtNome.Text;
                usuario.Email = txtEmail.Text;
                usuario.Nivel = Convert.ToInt32(txtNivel.Text);
                usuario.Login = txtLogin.Text;
                usuario.Senha = txtSenha.Text;
                if (btnSalvar.Tag.ToString() == "i")
                {
                    clBd.Incluir(usuario);
                    if (usuario.Codigo == 0)
                        MessageBox.Show("registro não incluido");
                }
                else
                    clBd.Alterar(usuario, Convert.ToInt32(txtCodigo.Text));
                btnSalvar.Tag = "a";
            }
            catch
            {
                MessageBox.Show("Não foi possível salvar");
            }
            finally
            {
                btnBuscar.Enabled = true;
                btnSalvar.Enabled = false;
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja " +
                "excluir este registro?", "Atenção",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                clBd.Excluir(Convert.ToInt32(txtCodigo.Text));
                btnExcluir.Enabled = false;
                btnSalvar.Enabled = false;
            }
            limpar();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
